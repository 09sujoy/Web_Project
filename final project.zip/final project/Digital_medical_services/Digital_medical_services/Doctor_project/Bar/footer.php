
<!DOCTYPE html>
<html>
<head>
<style>
.footer {
   position: relative;
   left: 0;
   bottom: -3%;
   width: 100%;
   text-align: center;
}
</style>
</head>
<body>
<footer class="footer">
	<hr>
  	<p style="text-align: center; color : ForestGreen">Copyright &#169 2021</p>
     <hr>
</footer>
</body>
</html>